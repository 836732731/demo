package com.cl.dao;

import com.cl.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserMapper {
    //增加用户
    int addUser(User user);

    //删除用户
    int deleteUserById(@Param("userid") int id);

    //更新用户
    int updateUser(User user);

    //查询用户
    User queryUserById(@Param("userid") int id);


    //查询全部用户
    List<User> queryAllUser();

    //模糊查询用户
    List<User> queryUserByName(@Param("username") String username);

    //查询用户
    User queryUserByusername(@Param("username") String username,@Param("password") String password);

}
