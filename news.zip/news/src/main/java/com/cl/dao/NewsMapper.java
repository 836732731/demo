package com.cl.dao;

import com.cl.pojo.News;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface NewsMapper {
    //增加新闻
    int addNews(News news);

    //删除新闻
    int deleteNewsById(@Param("newsId") int id);

    //更新新闻
    int updateNews(News news);

    //查询用户
    News queryNewsById(@Param("newsId") int id);


    //查询全部新闻
    List<News> queryAllNews();

    //模糊查询新闻
    List<News> queryNewsByName(@Param("newsTitle") String newsTitle);


}
