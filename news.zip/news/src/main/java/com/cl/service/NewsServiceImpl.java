package com.cl.service;

import com.cl.dao.NewsMapper;
import com.cl.pojo.News;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class NewsServiceImpl implements NewsService {
    private NewsMapper newsMapper;

    public void setNewsMapper(NewsMapper newsMapper) {
        this.newsMapper = newsMapper;
    }

    @Override
    public int addNews(News news) {
        return newsMapper.addNews(news);
    }

    @Override
    public int deleteNewsById(int id) {
        return newsMapper.deleteNewsById(id);
    }

    @Override
    public int updateNews(News news) {
        return newsMapper.updateNews(news);
    }

    @Override
    public News queryNewsById(int id) {
        return newsMapper.queryNewsById(id);
    }

    @Override
    public List<News> queryAllNews() {
        return newsMapper.queryAllNews();
    }

    @Override
    public List<News> queryNewsByName(String newTitle) {
        return newsMapper.queryNewsByName(newTitle);
    }
}
