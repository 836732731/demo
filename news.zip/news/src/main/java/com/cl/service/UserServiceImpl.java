package com.cl.service;

import com.cl.dao.UserMapper;
import com.cl.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public class UserServiceImpl implements UserService{
    //service调用dao层：组合dao层
    private UserMapper userMapper;
    public void setUserMapper(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @Override
    public int addUser(User user) {
        return userMapper.addUser(user);
    }

    @Override
    public int deleteUserById(int id) {
        return userMapper.deleteUserById(id);
    }

    @Override
    public int updateUser(User user) {
        return userMapper.updateUser(user);
    }

    @Override
    public User queryUserById(int id) {
        return userMapper.queryUserById(id);
    }

    @Override
    public List<User> queryAllUser() {
        return userMapper.queryAllUser();
    }

    @Override
    public List<User> queryUserByName(String username) {
        return  userMapper.queryUserByName(username);
    }

    @Override
    public User queryUserByusername(String username, String password) {
        return userMapper.queryUserByusername(username,password);
    }
}
