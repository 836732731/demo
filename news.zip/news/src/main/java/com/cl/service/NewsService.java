package com.cl.service;

import com.cl.pojo.News;
import org.apache.ibatis.annotations.Param;


import java.util.List;

public interface NewsService {
    //增加新闻
    int addNews(News news);

    //删除新闻
    int deleteNewsById(int id);

    //更新新闻
    int updateNews(News news);

    //查询新闻
    News queryNewsById(int id);

    //查询全部希望嫩
    List<News> queryAllNews();

    //查询新闻
    List<News> queryNewsByName(String newTitle);

}
