package com.cl.service;

import com.cl.pojo.User;
import org.apache.ibatis.annotations.Param;


import java.util.List;

public interface UserService {
    //增加用户
    int addUser(User user);

    //删除用户
    int deleteUserById(int id);

    //更新用户
    int updateUser(User user);

    //查询用户
    User queryUserById(int id);

    //查询全部用户
    List<User> queryAllUser();

    //查询用户
    List<User> queryUserByName(String username);

    //查询用户
    User queryUserByusername(String username,String password);


}
