package com.cl.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class News {
    private int newsId;
    private String newsTitle;
    private String newsContent;
    private String publishDate;
    private String newsPic;
}


