package com.cl.controller;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.core.lang.UUID;
import com.cl.pojo.News;
import com.cl.pojo.User;
import com.cl.service.NewsService;
import com.sun.org.apache.xpath.internal.operations.Mod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/news")
public class NewsController {
    @Autowired
    @Qualifier("NewsServiceImpl")
    private NewsService newsService;

    //查询全部新闻，并且返回到一个新闻展示页面
    @RequestMapping("/allNews")
    public String list(Model model){
        List<News> list = newsService.queryAllNews();
        model.addAttribute("list",list);
        return "allNews";
    }

    //跳转到发布新闻页面
    @RequestMapping("/toAddNews")
    public String toAddPaper(){
        return "addNews";
    }
    //发布新闻
    @RequestMapping("/addNews")
    public String addNews(News news, @RequestPart("file") MultipartFile file) throws IOException {
        String imageId = UUID.fastUUID().toString();
        String path = "C:\\Users\\chenl\\Desktop\\新建文件夹\\ssmnews\\img\\" + imageId + ".png";
        FileUtil.writeFromStream(file.getInputStream(), path);
        news.setNewsPic(imageId);
        newsService.addNews(news);
        return "redirect:/news/allNews";//重定向到@RequestMapping("/allUser")
    }

    @GetMapping(value = "/image/{imageId}", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> getImage(
            @PathVariable("imageId") String imageId
    ) {
        String path = "C:\\Users\\chenl\\Desktop\\新建文件夹\\ssmnews\\img\\" + imageId + ".png";
        byte[] imageContent = FileUtil.readBytes(path);
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.IMAGE_PNG);
        return new ResponseEntity<>(imageContent, headers, HttpStatus.OK);
    }

    //跳转到修改界面
    @RequestMapping("/toUpdateNews")
    public String toUpdatePaper(int id, Model model) {
        News news =newsService.queryNewsById(id);
        model.addAttribute("news", news);
        return "updateNews";

    }
    //修改新闻
    @RequestMapping("/updateNews")
    public  String updateNews(News news,@RequestPart("file") MultipartFile file) throws IOException {
        String imageId = UUID.fastUUID().toString();
        String path = "C:\\Users\\chenl\\Desktop\\新建文件夹\\ssmnews\\img\\" + imageId + ".png";
        FileUtil.writeFromStream(file.getInputStream(), path);
        news.setNewsPic(imageId);
        newsService.updateNews(news);
        return "redirect:/news/allNews";//重定向到@RequestMapping("/allUser")
    }
    //删除新闻
    @RequestMapping("/deleteNews")
    public String deleteNews(int id){
        newsService.deleteNewsById(id);
        return "redirect:/news/allNews";//重定向到@RequestMapping("/allUser")
    }
    //查询新闻
    @RequestMapping("/queryNews")
    public String queryNews(String queryNewsName,Model model){

        List<News> list=newsService.queryNewsByName(queryNewsName);
        if (list == null || list.isEmpty()){
            list = newsService.queryAllNews();
            model.addAttribute("error","未查到");
        }
        model.addAttribute("list",list);
        return "allNews";
    }

    //新闻详情页
    @RequestMapping("/newsDetail")
    public String newsDetail(int id,Model model){

        News news=newsService.queryNewsById(id);
        model.addAttribute("news",news);
        return "newsDetail";
    }

}
