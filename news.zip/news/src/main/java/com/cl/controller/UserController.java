package com.cl.controller;

import com.cl.pojo.User;
import com.cl.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    @Qualifier("UserServiceImpl")
    private UserService userService;

    //查询全部用户，并且返回到一个用户展示页面
    @RequestMapping("/allUser")
    public String list(Model model){
        List<User> list = userService.queryAllUser();
        model.addAttribute("list",list);
        return "allUser";
    }
    //跳转到注册页面
    @RequestMapping("/toAddUser")
    public String toAddPaper(){
        return "addUser";
    }
    //添加用户需求
    @RequestMapping("/addUser")
    public String addUser(User user){
        userService.addUser(user);
        return "redirect:/user/allUser";//重定向到@RequestMapping("/allUser")
    }
    //跳转用户登录页面
    @RequestMapping("/logining")
    public String toLogin(){
        return "login";
    }
    //用户登录
    @RequestMapping("/login")
    public String login(String username, String password, Model model, HttpSession httpSession){
        System.out.println("username："+username);
        User user=userService.queryUserByusername(username,password);

        if(username.equals("admin")){
            if (password.equals("123456")) {
                httpSession.setAttribute("loginuser","admin");
                return "redirect:/user/allUser";
            }else{
                model.addAttribute("error","登录失败");
                return "/login";
            }

        }else{
            if (user==null){
                model.addAttribute("error","登录失败");
                return "/login";
            }
        }
        httpSession.setAttribute("loginuser",user);
        return "redirect:/";
    }
    //跳转到修改界面
    @RequestMapping("/toUpdateUser")
    public String toUpdatePaper(int id,Model model){
        User user=userService.queryUserById(id);
        model.addAttribute("user",user);
        return "updateUser";
    }

    //修改用户
    @RequestMapping("/updateUser")
    public  String updateUser(User user){
        userService.updateUser(user);
        return "redirect:/user/allUser";//重定向到@RequestMapping("/allUser")
    }

    //删除用户
    @RequestMapping("/deleteUser")
    public String deleteUser(int id){
        userService.deleteUserById(id);
        return "redirect:/user/allUser";//重定向到@RequestMapping("/allUser")
    }
    //查询用户
    @RequestMapping("/queryUser")
    public String queryUser(String queryUserName,Model model){

        List<User> list=userService.queryUserByName(queryUserName);
        if (list == null || list.isEmpty()){
            list = userService.queryAllUser();
            model.addAttribute("error","未查到");
        }
        model.addAttribute("list",list);
        return "allUser";
    }
    //注销用户
    @RequestMapping("/logout")
    public String logout(HttpSession httpSession){

        httpSession.removeAttribute("loginuser");
        return "redirect:/";
    }
    //管理员注销
    @RequestMapping("/adminLogout")
    public String adminLogout(HttpSession httpSession){
        httpSession.removeAttribute("loginuser");
        return "redirect:/";
    }

}
