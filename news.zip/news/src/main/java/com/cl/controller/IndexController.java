package com.cl.controller;

import com.cl.dao.NewsMapper;
import com.cl.pojo.News;
import com.cl.service.NewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
public class IndexController {
    @Autowired
    @Qualifier("NewsServiceImpl")
    private NewsService newsService;


    @GetMapping("/")
    public String index(Model model) {
        List<News> list = newsService.queryAllNews();
        model.addAttribute("list",list);
        return "index";
    }


}
