package com.example.kaoshitest.Service;

import com.example.kaoshitest.dao.TeacherMapper;
import com.example.kaoshitest.pojo.t_teachers;
import com.example.kaoshitest.pojo.user;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TeacherServiceImp {
    @Autowired
    TeacherMapper teacherMapper;
    public t_teachers teacherLogin(user user){

            return teacherMapper.teacherLogin(user);


    }
}
