package com.example.kaoshitest.pojo;

import lombok.Data;

@Data
public class t_works {
    private int wid;
    private String wname;
    private String wcontent;
    private String p_time;
    private String f_time;
}
