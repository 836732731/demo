package com.example.kaoshitest.dao;


import com.example.kaoshitest.pojo.t_students;
import com.example.kaoshitest.pojo.user;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentMapper {
    @Select("Select * from t_students where sname=#{name} and spwd=#{pwd}")
    public t_students studentLogin(user user);
}
