package com.example.kaoshitest.pojo;

import lombok.Data;

@Data
public class t_students {
    private String sid;
    private String sname;
    private String spwd;
}
