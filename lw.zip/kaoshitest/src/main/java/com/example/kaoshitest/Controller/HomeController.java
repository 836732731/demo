package com.example.kaoshitest.Controller;

import com.example.kaoshitest.Service.StudentServiceImp;
import com.example.kaoshitest.Service.TeacherServiceImp;
import com.example.kaoshitest.Service.WorkServiceImp;
import com.example.kaoshitest.pojo.t_works;
import com.example.kaoshitest.pojo.user;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping({"","Home"})
public class HomeController {
    @Autowired
    TeacherServiceImp tsi;
    @Autowired
    StudentServiceImp ssi;
    @Autowired
    WorkServiceImp wsi;
    @RequestMapping({"","Login"})
    public String Login(Model model){
        return "Login";
    }
    @PostMapping("Logining")
    public String Logining(user user, Model model){
        System.out.println("user.name："+user.getName());
        System.out.println("user.pwd："+user.getPwd());
        System.out.println("user.role："+user.getRole());
        System.out.println(user.getRole().equals("教师"));
        if(user.getRole().equals("教师")){
            if(tsi.teacherLogin(user)!=null){
                model.addAttribute("info",user);
                return "Teacher";
            }
        }else{
            if(ssi.studentLogin( user)!=null){
                model.addAttribute("info",user);
                return "Student";
            }

        }
        return "Login";
    }
    @RequestMapping("toaddwork")
    public String ToAddWork(Model model){
        return "AddWork";
    }
    @RequestMapping("addworking")
    public String ToAddWork(t_works tw, Model model){
        if(wsi.addWork(tw)>0){
            model.addAttribute("info","作业发布成功");
        }else{
            model.addAttribute("info","作业发布失败");
        }
        return "AddWork";
    }
    @RequestMapping("toworkdetail")
    public String ToWorkDetail(Model model){
        List<t_works> worksList =wsi.queryAll();
        model.addAttribute("worklist",worksList);
        return "WorkDetail";
    }
    @RequestMapping("tostudentworkdetail")
    public String tostudentworkdetail(Model model){
        List<t_works> worksList =wsi.queryAll();
        model.addAttribute("worklist",worksList);
        return "StudentWorkDetail";
    }
    @RequestMapping("towork")
    public String ToWork(String wid,Model model){
        int id=Integer.parseInt(wid);
        t_works tw=wsi.queryByWid(id);
        model.addAttribute("workinfo",tw);
        return "Work";
    }
    @RequestMapping("Delete")
    public String Delete(String wid,Model model){
        int id=Integer.parseInt(wid);
        if(wsi.deleteWork(id)>0){
            model.addAttribute("info","删除成功");

        }else {
            model.addAttribute("info","删除失败");
        }
        List<t_works> worksList =wsi.queryAll();
        model.addAttribute("worklist",worksList);
        return "WorkDetail";
    }
}
