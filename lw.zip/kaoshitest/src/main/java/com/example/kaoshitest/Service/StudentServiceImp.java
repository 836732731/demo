package com.example.kaoshitest.Service;

import com.example.kaoshitest.dao.StudentMapper;
import com.example.kaoshitest.dao.TeacherMapper;

import com.example.kaoshitest.pojo.t_students;
import com.example.kaoshitest.pojo.user;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentServiceImp {
    @Autowired
    StudentMapper studentMapper;
    public t_students studentLogin(user user){

            return studentMapper.studentLogin(user);

    }
}
