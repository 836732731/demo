package com.example.kaoshitest.dao;

import com.example.kaoshitest.pojo.t_teachers;
import com.example.kaoshitest.pojo.user;

import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface TeacherMapper {
    @Select("Select * from t_teachers where tname=#{name} and tpwd=#{pwd}")
    public t_teachers teacherLogin(user user);
}
