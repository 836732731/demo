package com.example.kaoshitest.Service;

import com.example.kaoshitest.dao.WorkMapper;
import com.example.kaoshitest.pojo.t_works;
import com.sun.org.apache.regexp.internal.RE;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class WorkServiceImp {
@Autowired
    WorkMapper workMapper;
    public int addWork(t_works tw){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        String p_time=sdf.format(date).toString();
        tw.setP_time(p_time);
        if(workMapper.addWork(tw)>0){
            return 1;
        }
        return 0;
    }

    public int deleteWork(@Param("wid") int wid){
        if(workMapper.deleteWork(wid)>0){
            return 1;
        }
        return 0;

    }
    public List<t_works> queryAll(){
        return workMapper.queryAll();
    }
    public t_works queryByWid(int wid){
        return workMapper.queryByWid(wid);
    }
}
