package com.example.kaoshitest.pojo;

import lombok.Data;

@Data
public class t_teachers {
    private String tid;
    private String tname;
    private String tpwd;
}
