package com.example.kaoshitest.dao;

import com.example.kaoshitest.pojo.t_works;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WorkMapper {
    @Insert("insert into t_works(wname,wcontent,p_time,f_time)values(#{wname},#{wcontent},#{p_time},#{f_time})")
    public int addWork(t_works tw);

    @Delete("Delete from t_works where wid=#{wid}")
    public int deleteWork(@Param("wid") int wid);

    @Select("Select * from t_works")
    public List<t_works> queryAll();

    @Select("Select * from t_works where wid=#{wid}")
    public t_works queryByWid(@Param("wid")int wid);
}
